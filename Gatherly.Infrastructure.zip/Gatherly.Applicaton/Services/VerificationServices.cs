﻿using Gatherly.Domain.Entities;
using Gatherly.Domain.IRepositories;
using Gatherly.Domain.layer;

namespace Gatherly.Application.Services
{
    public class VerificationService
    {
        private readonly IVerificationRepository _verificationRepository;
        private readonly IPassRepository _passRepository;

        public VerificationService(IVerificationRepository verificationRepository, IPassRepository passRepository)
        {
            _verificationRepository = verificationRepository;
            _passRepository = passRepository;
        }

        public object ScanPass(Guid eventId, string qrPayload, string gateId, string deviceId)
        {
            var pass = _passRepository.GetById(Guid.TryParse(qrPayload, out var id) ? id : Guid.Empty);

            ScanResult result = ScanResult.InvalidPass;
            string message = "QR payload is invalid or tampered.";
            string attendeeName = "Unknown";
            string ticketType = "General";
            Guid passId = Guid.Empty;

            if (pass != null)
            {
                passId = pass.PassId;
                attendeeName = pass.AttendeeName;
                ticketType = pass.TicketType;

                if (pass.EventId != eventId)
                {
                    result = ScanResult.NotAllowed;
                    message = "Pass belongs to a different event.";
                }
                else if (pass.Status is (string)PassStatus.Invalidated or (string)PassStatus.Flagged)
                {
                    result = ScanResult.Flagged;
                    message = "Pass is flagged — alert security team.";
                }
                else if (_verificationRepository.GetAttendeeStatus(pass.PassId) == "Inside")
                {
                    result = ScanResult.AlreadyUsed;
                    message = "Pass already scanned — duplicate access denied.";
                }
                else
                {
                    result = ScanResult.Approved;
                    message = "Access granted. Welcome!";
                    pass.Status = PassStatus.Used;
                    _passRepository.Update(pass);
                    _verificationRepository.RecordAttendeeStatus(pass.PassId, "Inside");
                }
            }

            var log = new VerificationLog
            {
                EventId = eventId,
                PassId = passId,
                AttendeeName = attendeeName,
                TicketType = ticketType,
                Result = result,
                GateId = gateId
            };
            _verificationRepository.AddLog(log);

            return new { result = result.ToString(), attendeeName, ticketType, passId, message, checkedInAt = DateTime.UtcNow };
        }

        public IEnumerable<object> ManualSearch(Guid eventId, string searchTerm, string gateId)
        {
            return new List<object>
            {
                new { passId = Guid.NewGuid(), attendeeName = searchTerm, ticketType = "General", passStatus = PassStatus.Active.ToString(), checkedIn = false }
            };
        }

        public IEnumerable<VerificationLog> GetLog(Guid eventId) => _verificationRepository.GetLogsByEventId(eventId);

        public object GetActiveAttendees(Guid eventId)
        {
            var logs = _verificationRepository.GetLogsByEventId(eventId).Where(l => l.Result == ScanResult.Approved);
            return new
            {
                eventId,
                currentlyInside = logs.Count(),
                attendees = logs.Select(l => new { l.PassId, l.AttendeeName, l.TicketType, checkedInAt = l.ScannedAt })
            };
        }
    }
}