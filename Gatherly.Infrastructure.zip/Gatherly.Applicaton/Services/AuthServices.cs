﻿
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Gatherly.Application.DTOs;
using Gatherly.Application.Interfaces;
using Gatherly.Applicaton.DTOs;
using Gatherly.Applicaton.IServices;
using Gatherly.Domain.Entities;
using Gatherly.Domain.IRepositories;
using Microsoft.IdentityModel.Tokens;

namespace Gatherly.Application.Services
{
    public class AuthService : IAuthServices
    {
        private readonly IUserRepository _userRepository;
        private const string JwtSecret = "GatherlySuperSecretKey2026SecureString!";

        public AuthService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<RegisterResponseDto> RegisterAsync(ResgisterRequestDto request)
        {
            var existingUser = await _userRepository.GetByIdentifierAsync(request.Email ?? request.Phone);
            if (existingUser != null)
                throw new Exception("Email or phone number already registered");

            string firstName = string.Empty;
            string lastName = string.Empty;
            if (!string.IsNullOrWhiteSpace(request.FullName))
            {
                var nameParts = request.FullName.Trim().Split(new[] { ' ' }, 2);
                firstName = nameParts[0];
                if (nameParts.Length > 1) lastName = nameParts[1];
            }

            var user = new ApplicationUser
            {
                Id = Guid.NewGuid(),
                FirstName = firstName,
                LastName = lastName,
                Email = request.Email,
                UserName = request.Email,
                PhoneNumber = request.Phone,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
                Role = request.Role
            };

            await _userRepository.AddAsync(user);

            return new RegisterResponseDto
            {
                UserId = user.Id,
                FullName = user.FullName,
                Email = user.Email,
                Role = user.Role,
                CreatedAt = user.CreatedAt
            };
        }

        // FIX: Changed parameter type from LoginRequest to LoginRequestDto to satisfy CS0535
        public async Task<LoginResponseDto> LoginAsync(LoginRequestDto request)
        {
            var user = await _userRepository.GetByIdentifierAsync(request.Identifier);
            if (user == null || !BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
                throw new Exception("Invalid credentials");

            var accessToken = GenerateJwtToken(user);
            var refreshToken = GenerateRefreshTokenString();

            user.RefreshToken = refreshToken;
            user.RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(7);

            await _userRepository.UpdateAsync(user);

            return new LoginResponseDto
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken,
                ExpiresIn = 3600,
                User = new UserLoginDto
                {
                    UserId = user.Id,
                    FullName = user.FullName,
                    Email = user.Email,
                    Role = user.Role
                }
            };
        }

        public async Task<TokenResponseDto> RefreshTokenAsync(RefreshTokenRequestdDTO request)
        {
            var user = await _userRepository.GetByRefreshTokenAsync(request.RefreshToken);
            if (user == null || user.RefreshTokenExpiryTime <= DateTime.UtcNow)
                throw new Exception("Refresh token expired or invalid");

            var newAccessToken = GenerateJwtToken(user);

            return new TokenResponseDto
            {
                AccessToken = newAccessToken,
                ExpiresIn = 3600
            };
        }

        public async Task LogoutAsync(Guid userId)
        {
            var user = await _userRepository.GetByIdAsync(userId);
            if (user != null)
            {
                user.RefreshToken = null;
                user.RefreshTokenExpiryTime = DateTime.MinValue;
                await _userRepository.UpdateAsync(user);
            }
        }

        // FIX: Changed parameter type from ForgotPasswordRequest to ForgotPasswordRequestDto to satisfy CS0535
        public async Task ForgotPasswordAsync(ForgetPasswordRequestDto request)
        {
            var user = await _userRepository.GetByIdentifierAsync(request.Identifier);
            if (user != null)
            {
                user.ResetToken = Guid.NewGuid().ToString("N");
                user.ResetTokenExpiryTime = DateTime.UtcNow.AddHours(1);
                await _userRepository.UpdateAsync(user);
            }
        }

        // FIX: Changed parameter type from ResetPasswordRequest to ResetPasswordRequestDto to satisfy CS0535
        public async Task ResetPasswordAsync(ResetPasswordRequestDto request)
        {
            var user = await _userRepository.GetByResetTokenAsync(request.ResetToken);
            if (user == null || user.ResetTokenExpiryTime <= DateTime.UtcNow)
                throw new Exception("Token expired or invalid");

            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.NewPassword);
            user.ResetToken = null;
            user.ResetTokenExpiryTime = DateTime.MinValue;
            await _userRepository.UpdateAsync(user);
        }

        public async Task<UserProfileResponseDto> GetProfileAsync(Guid userId)
        {
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null) throw new Exception("User not found");

            return new UserProfileResponseDto
            {
                UserId = user.Id,
                FullName = user.FullName,
                Email = user.Email,
                Phone = user.PhoneNumber,
                Role = user.Role,
                ProfilePhoto = user.ProfilePhoto,
                CreatedAt = user.CreatedAt
            };
        }

        public async Task UpdateProfileAsync(Guid userId, UpdateProfileRequestDto request)
        {
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null) throw new Exception("User not found");

            if (!string.IsNullOrWhiteSpace(request.FullName))
            {
                var nameParts = request.FullName.Trim().Split(new[] { ' ' }, 2);
                user.FirstName = nameParts[0];
                user.LastName = nameParts.Length > 1 ? nameParts[1] : string.Empty;
            }

            user.PhoneNumber = request.Phone ?? user.PhoneNumber;
            user.ProfilePhoto = request.ProfilePhoto ?? user.ProfilePhoto;
            user.UpdatedAt = DateTime.UtcNow;

            await _userRepository.UpdateAsync(user);
        }

        private string GenerateJwtToken(ApplicationUser user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(JwtSecret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Role, user.Role ?? "User"),
                    new Claim(ClaimTypes.Email, user.Email ?? "")
                }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private string GenerateRefreshTokenString()
        {
            var randomNumber = new byte[32];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }
    }
}