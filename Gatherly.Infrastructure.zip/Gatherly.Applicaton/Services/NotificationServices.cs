﻿using System;
using System.Collections.Generic;
using Gatherly.Domain.Entities;
using Gatherly.Domain.IRepositories;

namespace Gatherly.Application.Services
{
    public class NotificationService
    {
        private readonly INotificationRepository _notificationRepository;

        public NotificationService(INotificationRepository notificationRepository)
        {
            _notificationRepository = notificationRepository;
        }

        public IEnumerable<Notification> GetNotificationsForUser(Guid userId) =>
            _notificationRepository.GetByUserId(userId);

        public bool MarkAsRead(Guid notificationId)
        {
            var notification = _notificationRepository.GetById(notificationId);
            if (notification == null) return false;

            notification.IsRead = true;
            _notificationRepository.Update(notification);
            return true;
        }

        public void MarkAllNotificationsAsRead(Guid userId) =>
            _notificationRepository.MarkAllAsRead(userId);
    }
}