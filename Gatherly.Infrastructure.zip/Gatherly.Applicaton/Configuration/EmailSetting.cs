﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gatherly.Application.Configuration
{
    public class EmailSettings
    {
        public string Host { get; init; } = string.Empty;
        public string Port { get; init; } = string.Empty;
        public string Username { get; init; } = string.Empty;
        public string Password { get; init; } = string.Empty;
    }
}
