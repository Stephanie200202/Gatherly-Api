﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gatherly.Applicaton.Configuration
{
    internal class FileUploadSettings
    {
    }
}
