﻿using Gatherly.Applicaton.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gatherly.Applicaton.IServices
{
    public interface IAuthServices
    {
        Task<RegisterResponseDto> RegisterAsync(ResgisterRequestDto request);
        Task<LoginResponseDto> LoginAsync(LoginRequestDto request);
        Task<TokenResponseDto> RefreshTokenAsync(RefreshTokenRequestdDTO request);
        Task LogoutAsync(Guid userId);
        Task ForgotPasswordAsync(ForgetPasswordRequestDto request);
        Task ResetPasswordAsync(ResetPasswordRequestDto request);
        Task<UserProfileResponseDto> GetProfileAsync(Guid userId);
        Task UpdateProfileAsync(Guid userId, UpdateProfileRequestDto request);
    }
}
