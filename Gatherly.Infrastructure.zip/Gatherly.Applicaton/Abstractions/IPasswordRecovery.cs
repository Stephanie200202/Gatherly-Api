﻿using Gatherly.Applicaton.DTOs;

namespace Gatherly.Application.Abstractions
{
    public interface IPasswordRecovery
    {


        Task<bool> ForgotPasswordAsync(ForgetPasswordRequestDto forgotPasswordDto);
        Task<bool> ResetPasswordAsync(ResetPasswordRequestDto resetPasswordDto);

    }
}
