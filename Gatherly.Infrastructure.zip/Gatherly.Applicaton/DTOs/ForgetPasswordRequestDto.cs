﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gatherly.Applicaton.DTOs
{
    public class ForgetPasswordRequestDto
    {
        public string Identifier { get; set; }
    }
}
