﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gatherly.Applicaton.DTOs
{
    public class ResetPasswordRequestDto
    {
        public string ResetToken { get; set; }
        public string NewPassword { get; set; }
    }
}
