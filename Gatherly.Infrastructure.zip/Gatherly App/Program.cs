using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// =========================================================================
// 1. CONFIGURATION BINDINGS VIA OPTIONS PATTERN
// =========================================================================
builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection("Jwt"));
builder.Services.Configure<EmailSetting>(builder.Configuration.GetSection("EmailSettings"));
builder.Services.Configure<FileUploadSettings>(builder.Configuration.GetSection("FileUpload"));

// =========================================================================
// 2. DATABASE CONTEXT ENGINE SETUP (SQL Server)
// =========================================================================
builder.Services.AddDbContext<ApplicationDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// =========================================================================
// 3. PERSISTENCE LAYER DATA ADAPTOR MAPPINGS
// =========================================================================
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IEventRepository, EventRepository>();
builder.Services.AddScoped<IRegistrationRepository, RegistrationRepository>();
builder.Services.AddScoped<IPassRepository, PassRepository>();
builder.Services.AddScoped<IVerificationRepository, VerificationRepository>();
builder.Services.AddScoped<INotificationRepository, NotificationRepository>();
builder.Services.AddScoped<IAnnouncementRepository, AnnouncementRepository>();

// =========================================================================
// 4. APPLICATION WORKFLOW LAYER WIRE-UP (Clean, Interface-Free Services)
// =========================================================================
builder.Services.AddScoped<CoreWorkFlowService>();
builder.Services.AddScoped<PassService>();
builder.Services.AddScoped<VerificationService>();
builder.Services.AddScoped<NotificationService>();
builder.Services.AddScoped<AnnouncementService>();

// =========================================================================
// 5. CROSS-CUTTING INFRASTRUCTURE & IDENTITY SERVICES
// =========================================================================
builder.Services.AddScoped<IPasswordRecoveryService, PasswordRecoveryService>();
builder.Services.AddScoped<IJwtProvider, JwtProvider>();
builder.Services.AddScoped<ICurrentUserService, CurrentUserService>();
builder.Services.AddHttpContextAccessor();

// Registered as Transient for fast, isolated background email dispatches
builder.Services.AddTransient<IEmailService, EmailService>();

// =========================================================================
// 6. NATIVE AUTHENTICATION CONTEXT ENGINE SETUP
// =========================================================================
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:SecretKey"]!)),
            RoleClaimType = "role" // Forces token validation engine to correctly process simple "role" claims
        };

        options.Events = new JwtBearerEvents
        {
            OnAuthenticationFailed = context =>
            {
                System.Diagnostics.Debug.WriteLine("JWT Auth Failed: " + context.Exception.Message);
                return Task.CompletedTask;
            }
        };
    });

// =========================================================================
// 7. SWAGGER / OPENAPI SPECIFICATION GENERATION WITH JWT PADLOCK
// =========================================================================
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    // Configure how Swagger UI visually reads the Bearer token authorization header
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header using the Bearer scheme. Example: \"Bearer {token}\"",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "Bearer",
        BearerFormat = "JWT"
    });

    // Apply the padlock requirement globally to secure api pathways
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

// =========================================================================
// 8. MIDDLEWARE PIPELINE EXECUTION
// =========================================================================
if (app.Environment.IsDevelopment() || app.Environment.IsStaging())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Gatherly API v1.0");
        c.RoutePrefix = "swagger";
    });
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();