﻿using Gatherly.Application.Abstractions;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace Gatherly.Infrastructure.Services;

public class CurrentUserService : ICurrentUserService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public CurrentUserService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    // 1. Parse the NameIdentifier claim into a string to match your interface


    public string UserId
    {
        get
        {
            var userIdClaim = _httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);
            return userIdClaim ?? string.Empty;
        }
    }


    // 2. Grab the Role string to match your interface
    public string Role => _httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.Role) ?? string.Empty;
}