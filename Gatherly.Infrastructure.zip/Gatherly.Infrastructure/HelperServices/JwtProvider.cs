﻿//using System.IdentityModel.Tokens.Jwt;
//using System.Security.Claims;
//using System.Text;
//using Gatherly.Application.Abstractions;
//using Gatherly.Application.Configuration;
//using Gatherly.Domain.Entities; // Adjust this namespace if your User class sits elsewhere
//using Microsoft.AspNetCore.Identity;
//using Microsoft.Extensions.Options;
//using Microsoft.IdentityModel.Tokens;

//namespace Gatherly.Infrastructure.Provider;

//public class JwtProvider : IJwtProvider
//{
//    private readonly JwtSettings _jwtSettings;

//    public JwtProvider(IOptions<JwtSettings> jwtSettings)
//    {
//        _jwtSettings = jwtSettings.Value;
//    }

//    // 1. Matches your interface signature: GenerateToken
//    public TokenResult GenerateToken(ApplicationUser user)
//    {
//        var tokenHandler = new JwtSecurityTokenHandler();
//        var key = Encoding.UTF8.GetBytes(_jwtSettings.SecretKey);

//        var claims = new List<Claim>
//{
//    new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
//    new Claim("role", user.Role.ToString()),
//    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()) // <--- Fixed here
//};

//        if (!string.IsNullOrEmpty(user.Email))
//        {
//            claims.Add(new Claim(JwtRegisteredClaimNames.Email, user.Email));
//        }

//        var tokenDescriptor = new SecurityTokenDescriptor
//        {
//            Subject = new ClaimsIdentity(claims),
//            Expires = DateTime.UtcNow.AddMinutes(_jwtSettings.AccessTokenExpirationMinutes),
//            Issuer = _jwtSettings.Issuer,
//            Audience = _jwtSettings.Audience,
//            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
//        };

//        var token = tokenHandler.CreateToken(tokenDescriptor);
//        var accessToken = tokenHandler.WriteToken(token);

//        // Generate a random string payload for the refresh token channel
//        var refreshToken = Guid.NewGuid().ToString("N");

//        // Adjust properties below to match fields inside your actual TokenResult definition
//        return new TokenResult
//        {
//            AccessToken = accessToken,
//            RefreshToken = refreshToken,
//            ExpiresIn = _jwtSettings.AccessTokenExpirationMinutes * 60
//        };
//    }

//    // 2. Matches your interface signature: GetPrincipalFromExpiredToken
//    public ClaimsPrincipal? GetPrincipalFromExpiredToken(string token)
//    {
//        var tokenValidationParameters = new TokenValidationParameters
//        {
//            ValidateAudience = true,
//            ValidateIssuer = true,
//            ValidIssuer = _jwtSettings.Issuer,
//            ValidAudience = _jwtSettings.Audience,
//            ValidateIssuerSigningKey = true,
//            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.SecretKey)),
//            ValidateLifetime = false // Crucial: We need to read claims from an already expired token
//        };

//        var tokenHandler = new JwtSecurityTokenHandler();
//        try
//        {
//            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out SecurityToken securityToken);

//            if (securityToken is not JwtSecurityToken jwtSecurityToken ||
//                !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
//            {
//                return null;
//            }

//            return principal;
//        }
//        catch
//        {
//            return null; // Return null safely if validation or decoding breaks completely
//        }
//    }
//}