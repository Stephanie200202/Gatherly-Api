﻿using Gatherly.Application.Abstractions;
using Gatherly.Application.Configuration;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;
using System.Net.Mail;
using System.Threading.Tasks;
using SmtpClient = MailKit.Net.Smtp.SmtpClient;

namespace Gatherly.Infrastructure.Services
{
    public class EmailService : IEmailService
    {
        private readonly EmailSettings _emailSettings;

        public EmailService(IOptions<EmailSettings> emailSettings)
        {
            _emailSettings = emailSettings.Value;
        }

        public async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            var mailMessage = new MimeMessage();
            mailMessage.From.Add(new MailboxAddress("Gatherly Platform", _emailSettings.Username));
            mailMessage.To.Add(new MailboxAddress("", toEmail));
            mailMessage.Subject = subject;

            var bodyBuilder = new BodyBuilder { HtmlBody = body };
            mailMessage.Body = bodyBuilder.ToMessageBody();

            using var client = new SmtpClient();

            // Uses clean strongly-typed configuration options directly
            await client.ConnectAsync(_emailSettings.Host, _emailSettings.Port, SecureSocketOptions.Auto);
            await client.AuthenticateAsync(_emailSettings.Username, _emailSettings.Password);

            await client.SendAsync(mailMessage);
            await client.DisconnectAsync(true);
        }
    }
}
