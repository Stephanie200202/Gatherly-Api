﻿using Gatherly.Domain.Entities;
using Gatherly.Domain.Interfaces;
using Gatherly.Presentation.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Gatherly.Infrastructure.Repositories
{
    public class FeedbackRepository : IFeedbackRepository
    {
        private static readonly List<Feedback> _feedbacks = new List<Feedback>();

        public Task<Feedback?> GetByIdAsync(Guid feedbackId)
        {
            var feedback = _feedbacks.FirstOrDefault(f => f.FeedbackId == feedbackId);
            return Task.FromResult(feedback);
        }

        public Task<Feedback?> GetByUserAndEventAsync(Guid userId, Guid eventId)
        {
            var feedback = _feedbacks.FirstOrDefault(f => f.UserId == userId && f.EventId == eventId);
            return Task.FromResult(feedback);
        }

        public Task<IEnumerable<Feedback>> GetByEventIdAsync(Guid eventId)
        {
            var eventFeedback = _feedbacks.Where(f => f.EventId == eventId).ToList();
            return Task.FromResult<IEnumerable<Feedback>>(eventFeedback);
        }

        public Task<bool> AddAsync(Feedback feedback)
        {
            _feedbacks.Add(feedback);
            return Task.FromResult(true);
        }

        public Task<bool> DeleteAsync(Guid feedbackId)
        {
            var feedback = _feedbacks.FirstOrDefault(f => f.FeedbackId == feedbackId);
            if (feedback != null)
            {
                _feedbacks.Remove(feedback);
                return Task.FromResult(true);
            }
            return Task.FromResult(false);
        }
    }
}
