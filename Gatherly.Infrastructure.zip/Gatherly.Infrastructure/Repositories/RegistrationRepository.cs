﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gatherly.Domain.Interfaces;
using Gatherly.Domain.Entities;

namespace Gatherly.Infrastructure.Repositories
{
    public class RegistrationRepository : IRegistrationRepository
    {
        private static readonly List<Registration> _registrations = new List<Registration>();

        public Task<Registration?> GetByIdAsync(Guid registrationId)
        {
            var target = _registrations.FirstOrDefault(r => r.RegistrationId == registrationId);
            return Task.FromResult(target);
        }

        public Task<Registration?> GetByUserAndEventAsync(Guid userId, Guid eventId)
        {
            var target = _registrations.FirstOrDefault(r => r.UserId == userId && r.EventId == eventId);
            return Task.FromResult(target);
        }

        public Task<IEnumerable<Registration>> GetByEventIdAsync(Guid eventId)
        {
            var eventRegs = _registrations.Where(r => r.EventId == eventId).ToList();
            return Task.FromResult<IEnumerable<Registration>>(eventRegs);
        }

        public Task<IEnumerable<Registration>> GetByUserIdAsync(Guid userId)
        {
            var userRegs = _registrations.Where(r => r.UserId == userId).ToList();
            return Task.FromResult<IEnumerable<Registration>>(userRegs);
        }

        public Task<bool> AddAsync(Registration registration)
        {
            _registrations.Add(registration);
            return Task.FromResult(true);
        }

        public Task<bool> UpdateAsync(Registration registration)
        {
            var index = _registrations.FindIndex(r => r.RegistrationId == registration.RegistrationId);
            if (index != -1)
            {
                _registrations[index] = registration;
                return Task.FromResult(true);
            }
            return Task.FromResult(false);
        }

        public Task<int> GetCountByEventIdAsync(Guid eventId)
        {
            int counter = _registrations.Count(r => r.EventId == eventId && r.Status != "Cancelled");
            return Task.FromResult(counter);
        }
    }
}