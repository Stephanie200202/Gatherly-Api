﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gatherly.Domain.Entities;
using Gatherly.Domain.Interfaces;
using Gatherly.Domain.IRepositories;

namespace Gatherly.Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        // Thread-safe in-memory collection simulating a real database
        private static readonly List<ApplicationUser> _users = new List<ApplicationUser>();

        public Task<ApplicationUser> GetByIdAsync(Guid id)
        {
            var user = _users.FirstOrDefault(u => u.UserId == id);
            return Task.FromResult(user);
        }

        public Task<ApplicationUser> GetByIdentifierAsync(string identifier)
        {
            var user = _users.FirstOrDefault(u => u.Email == identifier || u.Phone == identifier);
            return Task.FromResult(user);
        }

        public Task<ApplicationUser> GetByRefreshTokenAsync(string refreshToken)
        {
            var user = _users.FirstOrDefault(u => u.RefreshToken == refreshToken);
            return Task.FromResult(user);
        }

        public Task<ApplicationUser> GetByResetTokenAsync(string resetToken)
        {
            var user = _users.FirstOrDefault(u => u.ResetToken == resetToken);
            return Task.FromResult(user);
        }

        public Task AddAsync(ApplicationUser user)
        {
            _users.Add(user);
            return Task.CompletedTask;
        }

        public Task UpdateAsync(ApplicationUser user)
        {
            var index = _users.FindIndex(u => u.UserId == user.UserId);
            if (index != -1)
            {
                _users[index] = user;
            }
            return Task.CompletedTask;
        }
    }
}