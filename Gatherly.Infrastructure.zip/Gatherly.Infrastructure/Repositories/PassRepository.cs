﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using Gatherly.Domain.Entities;
using Gatherly.Domain.IRepositories;

namespace Gatherly.Infrastructure.Persistence
{
    public class PassRepository : IPassRepository
    {
        // Thread-safe collection acting as your temporary database table
        private static readonly ConcurrentDictionary<Guid, Pass> _passes = new();

        public Pass? GetById(Guid passId) =>
            _passes.TryGetValue(passId, out var pass) ? pass : null;

        public Pass? GetByRegistrationId(Guid registrationId) =>
            _passes.Values.FirstOrDefault(p => p.RegistrationId == registrationId);

        public void Add(Pass pass) =>
            _passes[pass.PassId] = pass;

        public void Update(Pass pass) =>
            _passes[pass.PassId] = pass;
    }
}