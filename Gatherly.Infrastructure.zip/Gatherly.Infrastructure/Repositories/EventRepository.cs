﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gatherly.Domain.Interfaces;
using Gatherly.Domain.Entities;

namespace Gatherly.Infrastructure.Repositories
{
    public class EventRepository : IEventRepository
    {
        // A simple, static list that acts as our temporary database table
        private static readonly List<Event> _events = new List<Event>();

        // 1. Get a single event by its ID
        public Task<Event?> GetByIdAsync(Guid eventId)
        {
            var foundEvent = _events.FirstOrDefault(e => e.EventId == eventId);
            return Task.FromResult(foundEvent);
        }

        // 2. Get public events with easy filtering and pagination
        public Task<Tuple<IEnumerable<Event>, int>> GetPublicEventsAsync(int page, int pageSize, string? category, string? search, string? date)
        {
            // Start with only public events
            var query = _events.Where(e => e.Visibility == "Public");

            // Filter by category if one is provided
            if (!string.IsNullOrEmpty(category))
            {
                query = query.Where(e => e.Category.Equals(category, StringComparison.OrdinalIgnoreCase));
            }

            // Filter by search keyword (checks title or venue) if provided
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(e => e.Title.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                                         e.Venue.Contains(search, StringComparison.OrdinalIgnoreCase));
            }

            // Filter by specific date if provided
            if (!string.IsNullOrEmpty(date))
            {
                query = query.Where(e => e.Date == date);
            }

            // Count total matches before chopping them up into pages
            int totalCount = query.Count();

            // Paginate using simple Skip and Take commands
            var paginatedItems = query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            // Return both the list of events and the total count back to the service layer
            return Task.FromResult(new Tuple<IEnumerable<Event>, int>(paginatedItems, totalCount));
        }

        // 3. Get all events created by a specific organizer
        public Task<IEnumerable<Event>> GetEventsByOrganizerAsync(Guid organizerId)
        {
            var organizerEvents = _events.Where(e => e.OrganizerId == organizerId).ToList();
            return Task.FromResult<IEnumerable<Event>>(organizerEvents);
        }

        // 4. Add a new event to our list
        public Task<bool> AddAsync(Event eventEntity)
        {
            _events.Add(eventEntity);
            return Task.FromResult(true);
        }

        // 5. Update an existing event inside our list
        public Task<bool> UpdateAsync(Event eventEntity)
        {
            // Find where the event lives in our list
            var index = _events.FindIndex(e => e.EventId == eventEntity.EventId);

            if (index != -1)
            {
                // Replace the old event data with the updated event data
                _events[index] = eventEntity;
                return Task.FromResult(true);
            }

            return Task.FromResult(false);
        }

        // 6. Delete an event from our list entirely
        public Task<bool> DeleteAsync(Guid eventId)
        {
            var eventEntity = _events.FirstOrDefault(e => e.EventId == eventId);

            if (eventEntity != null)
            {
                _events.Remove(eventEntity);
                return Task.FromResult(true);
            }

            return Task.FromResult(false);
        }
    }
}