﻿using Gatherly.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gatherly.Domain.IRepositories
{
    public interface IAnnouncementRepository
    {
        void Add(Announcement announcement);
        IEnumerable<Announcement> GetByEventId(Guid eventId);
    }
}